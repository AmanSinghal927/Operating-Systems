#include <iostream>
#include "getopt.h"
#include <sstream>
#include <fstream>
#include <string.h> 
#include <cctype>
#include <cstdlib>
#include <vector>
#include <unordered_map>
#include <sstream>
#include <iomanip>
#include <algorithm>
#include <list>
#include <deque>
#include <limits>
#include <cstdio>
// #include <getopt.h>
# include <list>
using namespace std;

int simulation_time = 0;
int hand = 0;
int direction = 1;
int curr_disk = 0;
int prev_hand = -1;
int total_time = 0;
int io_time = 0; 
int tot_movement = 0; 
double io_utilization; 
int turnaround = 0;
double avg_turnaround; 

int waittime = 0;
double avg_waittime; 
int max_waittime = 0;
int ret_simulation_time;



struct Request{
    public:
        int arr_time;
        int start_time;
        int end_time;
        int io_disk;
        int req_no;

        Request(int req_no, int arr_time, int io_disk, int start_time, int end_time){
            this->req_no = req_no;
            this->io_disk = io_disk;
            this->arr_time = arr_time;
            this->start_time = start_time;
            this->end_time = end_time;
        }
};

vector<Request> IOqueue;
vector<Request> completed_IO;
vector<Request> Q1;
vector<Request> Q2;



class Shed{
    public:
    virtual int select_victim() = 0; // gives victim frame
};
Shed *shed;

class FIFO: public Shed
{
    public:
    int hand;
        FIFO(int hand = 0)
        {
            this->hand = hand;
        }

        int select_victim()
        {
            hand = IOqueue[0].io_disk;
            if (prev_hand!=-1){
                if (prev_hand>hand){
                    // printf("PREV HAND IS %d\n", prev_hand);
                    direction = -1;
                }
                else{
                    if (prev_hand==hand){
                        direction = 0;
                    }
                    else{
                    // printf("PREV HAND IS %d\n", prev_hand);
                        direction = 1;
                    }
                }
            }
            else{
                // printf("PREV HAND NOT SET\n");
                direction = 1;
            }
            ret_simulation_time = simulation_time;
            return (0);
        }
};

class SSTF: public Shed{
    public:
    int hand;
    SSTF(int hand = 0){
        this->hand = hand;
    }
    // decide hand and direction --> direction logic should remain more or less same
    int select_victim(){
        int min_seek = 2147483647;
        int ret_idx = -1;
        Request r = IOqueue[0];
        int i = 0;
        while ((r.arr_time<=simulation_time) && (i<IOqueue.size())){
            if (min_seek>abs(r.io_disk - prev_hand)){
                ret_idx = i;
                min_seek = abs(r.io_disk - prev_hand);
                hand = IOqueue[ret_idx].io_disk;
                }
            i++;
            r = IOqueue[i];
            
        }

        if (prev_hand!=-1){
            if (prev_hand>hand){
                // printf("PREV HAND IS %d\n", prev_hand);
                direction = -1;
            }
            else{
                if (prev_hand==hand){
                    direction = 0;
                }
                else{
                // printf("PREV HAND IS %d\n", prev_hand);
                    direction = 1;
                }
            }
        }
        else{
            // printf("PREV HAND NOT SET\n");
            direction = 1;
        }
        ret_simulation_time = simulation_time;
        return (ret_idx);
    }
};



class LOOK: public Shed{
    public:
    int hand;
    int prev_direction = 1;
    LOOK(int hand = 0){
        this->hand = hand;
    }
    // decide hand and direction --> direction logic should remain more or less same
    int select_victim(){
        // printf("DIRECTION FOR PICKING IS %d\n", direction);
        int min_seek = 2147483647;
        int ret_idx = -1;
        Request r = IOqueue[0];
        int i = 0;

        if (direction == 0){
            direction = prev_direction;
        }

        while ((r.arr_time<=simulation_time) && (i<IOqueue.size())){
            if (direction * (r.io_disk - prev_hand) >= 0 && min_seek > direction * (r.io_disk - prev_hand)) {
                ret_idx = i;
                min_seek = abs(r.io_disk - prev_hand);
                hand = IOqueue[ret_idx].io_disk;
                }
            i++;
            r = IOqueue[i];
            
        }

        if (ret_idx == -1){ // reverse direction if nothing is found
            direction = -direction;
            i = 0;
            r = IOqueue[0];
            while ((r.arr_time<=simulation_time) && (i<IOqueue.size())){
                if (direction * (r.io_disk - prev_hand) >= 0 && min_seek > direction * (r.io_disk - prev_hand)) {
                    ret_idx = i;
                    min_seek = abs(r.io_disk - prev_hand);
                    hand = IOqueue[ret_idx].io_disk;
                    }
                i++;
                r = IOqueue[i];
                
            }
        }

        if (prev_hand!=-1){
            if (prev_hand>hand){
                // printf("PREV HAND IS %d\n", prev_hand);
                direction = -1;
            }
            else{
                if (prev_hand==hand){
                    direction = 0;
                }
                else{
                // printf("PREV HAND IS %d\n", prev_hand);
                    direction = 1;
                }
            }
        }
        else{
            // printf("PREV HAND NOT SET\n");
            direction = 1;
        }

        if (direction!=0){
            prev_direction = direction;
        }

        ret_simulation_time = simulation_time;
        return (ret_idx);
    }
};


class CLOOK: public Shed{
    public:
    int hand;
    int prev_direction = 1;
    CLOOK(int hand = 0){
        this->hand = hand;
    }
    // decide hand and direction --> direction logic should remain more or less same
    int select_victim(){
        // printf("DIRECTION FOR PICKING IS %d\n", direction);
        int min_seek = 2147483647;
        int ret_idx = -1;
        Request r = IOqueue[0];
        int i = 0;

        if (direction == 0){
            direction = prev_direction;
        }

        while ((r.arr_time<=simulation_time) && (i<IOqueue.size())){
            if ((r.io_disk - prev_hand) >= 0 && min_seek > (r.io_disk - prev_hand)) {
                ret_idx = i;
                min_seek = abs(r.io_disk - prev_hand);
                hand = IOqueue[ret_idx].io_disk;
                }
            i++;
            r = IOqueue[i];
            
        }

        ret_simulation_time = simulation_time;


        if (ret_idx == -1){ // reset direction if nothing is found
            // printf("REVERSE\n");
            i = 0;
            r = IOqueue[0];
            int new_prev_hand = -1;
            while ((r.arr_time<=simulation_time) && (i<IOqueue.size())){
                if (direction * (r.io_disk - new_prev_hand) >= 0 && min_seek > direction * (r.io_disk - new_prev_hand)) {
                    ret_idx = i;
                    min_seek = abs(r.io_disk - new_prev_hand);
                    hand = IOqueue[ret_idx].io_disk;
                    }
                i++;
                r = IOqueue[i];
                
            }
            // printf("PICKED ELEMENT IS %d", IOqueue[ret_idx].io_disk);
            if (ret_idx!=-1){
                // printf("CURRENT DISK IS %d and NEW DISK IS %d\n", curr_disk, IOqueue[ret_idx].io_disk );
                ret_simulation_time = simulation_time;
                simulation_time = simulation_time + curr_disk - IOqueue[ret_idx].io_disk - 1;
                curr_disk = IOqueue[ret_idx].io_disk - 1;
            }
        }

        if (prev_hand!=-1){
            if (prev_hand==hand){
                direction = 0;
            }
            else{
            // printf("PREV HAND IS %d\n", prev_hand);
                direction = 1;
            }
        }
        else{
            // printf("PREV HAND NOT SET\n");
            direction = 1;
        }



        // if (ret_idx!=-1){
        //     printf("Picked IO for track %d Direction %d Time %d\n", IOqueue[ret_idx].io_disk, direction, simulation_time);
        // }
        // else{
        //     printf("No IO picked\n");
        // }

        if (direction!=0){
            prev_direction = direction;
        }
        return (ret_idx);
    }
};

void swap_vectors(vector<Request>** a, vector<Request>** b) {
    vector<Request>* temp = *a;
    *a = *b;
    *b = temp;
}

class FLOOK: public Shed{
    public:
    int hand;
    int prev_direction = 1;
    int prev_simulation_time = 0;
    vector<Request>* ptr2active = &Q1;
    vector<Request>* ptr2add = &Q2;

    // Vector 1 will search IOQ and check what IOs are available at a simulation_time
    // What if I send the indexes of the IOQueue
    // 

    FLOOK(int hand = 0){
        this->hand = hand;
    }
    // decide hand and direction --> direction logic should remain more or less same
    int select_victim(){

        for (int i = 0;i<IOqueue.size();i++){
            if ((IOqueue[i].arr_time>prev_simulation_time) && (IOqueue[i].arr_time<=simulation_time)){
                (*ptr2add).push_back(IOqueue[i]);
            }
        }

        // printf("Q1: ");
        // for (const auto &element:Q1){
        //     printf("IO %d, ", element.req_no);
        // }
        // printf("\n");
        // printf("Q2: ");
        // for (const auto &element:Q2){
        //     printf("IO %d, ", element.req_no);
        // }
        // printf("\n");

        prev_simulation_time = simulation_time;

        if (((*ptr2add).empty()) && ((*ptr2active).empty())){
            // printf("%d: Returning -1\n", simulation_time);
            return (-1);
        }

        // printf("%d: Going ahead\n", simulation_time);

        

        if ((*ptr2active).empty()){
            // swap
            // printf("%d: Swapped, activeQ size before %d\n", simulation_time, (*ptr2active).size());
            swap_vectors(&ptr2active, &ptr2add);
            // printf("%d: Swapped, activeQ size after %d\n", simulation_time, (*ptr2active).size());

        }


        // printf("DIRECTION FOR PICKING IS %d\n", direction);
        int min_seek = 2147483647;
        int ret_idx = -1;
        Request r = (*ptr2active)[0];
        int i = 0;
        int rm_idx;
        Request next_req = r;

        // printf("Picked request\n");

        if (direction == 0){
            direction = prev_direction;
        }

        while ((r.arr_time<=simulation_time) && (i<(*ptr2active).size())){
            r = (*ptr2active)[i];
            if (direction * (r.io_disk - prev_hand) >= 0 && min_seek > direction * (r.io_disk - prev_hand)) {
                min_seek = direction*(r.io_disk - prev_hand);
                next_req = r;
                hand = (*ptr2active)[i].io_disk;
                }
            i++;           
        }

        // printf("Selected request %d\n", ret_idx);

        if (min_seek == 2147483647){ // reverse direction if nothing is found
            // printf("REVERSE\n");
            direction = -direction;
            i = 0;
            r = (*ptr2active)[0];
            while ((r.arr_time<=simulation_time) && (i<(*ptr2active).size())){
                r = (*ptr2active)[i];
                if (direction * (r.io_disk - prev_hand) >= 0 && min_seek > direction * (r.io_disk - prev_hand)) {
                    min_seek = direction*(r.io_disk - prev_hand);
                    next_req = r;
                    hand = (*ptr2active)[i].io_disk;
                    }
                i++;
                
            }
        }

        if (prev_hand!=-1){
            if (prev_hand>hand){
                // printf("PREV HAND IS %d\n", prev_hand);
                direction = -1;
            }
            else{
                if (prev_hand==hand){
                    direction = 0;
                }
                else{
                // printf("PREV HAND IS %d\n", prev_hand);
                    direction = 1;
                }
            }
        }
        else{
            // printf("PREV HAND NOT SET\n");
            direction = 1;
        }

        if (direction!=0){
            prev_direction = direction;
        }

        if (min_seek != 2147483647){
            // printf("trying to erase\n");
            for (int i = 0;i<IOqueue.size();i++){
                if (next_req.req_no == IOqueue[i].req_no){
                    ret_idx = i;
                }
            }

            for (int i = 0;i<(*ptr2active).size();i++){
                if (next_req.req_no == (*ptr2active)[i].req_no){
                    rm_idx = i;
                    ptr2active->erase(ptr2active->begin()+rm_idx);
                }
            }
        }

        ret_simulation_time = simulation_time;
        return (ret_idx);
    }
};


// if (ret_idx!=-1){
//     printf("Picked IO for track %d Direction %d Time %d\n", IOqueue[ret_idx].io_disk, direction, simulation_time);
// }
// else{
//     printf("No IO picked\n");
// }
// Printing the IOQueue
// for (const auto &element:IOqueue){
//     printf("IO %d Arrival %d Seek %d\n", element.req_no, element.arr_time, element.io_disk);
// }



void simulate(){
    Request* curr_io = nullptr;
    // printf("INSIDE SIMULATE\n");
    int curr_io_idx = -1;
    while((!IOqueue.empty()) || (curr_io_idx!=-1)){ // edge case for the last completion
        // printf("CURRENT DISK IS %d\n", curr_disk);

        if ((curr_io_idx!=-1) && (curr_io->io_disk == curr_disk)){ // Exit condition
            if (direction==0){
                simulation_time--;
            }

            prev_hand = curr_io->io_disk;
            curr_io->end_time = simulation_time;
            // printf("%d: %d finish %d\n", simulation_time, curr_io->req_no, curr_io->end_time - curr_io->arr_time);
            // printf("EXITED IO DISK %d\n", curr_disk);
            completed_IO.push_back(*curr_io);
            IOqueue.erase(IOqueue.begin()+curr_io_idx);
            curr_io = nullptr;
            curr_io_idx = -1;
        }


        if (curr_io_idx==-1){
            int selected_victim = shed->select_victim();
            if (selected_victim!=-1){
                if (IOqueue.empty()){ // No more IOs left to process
                    return;
                }
                // printf("PICKED curr_io_idx %d\n", curr_io_idx);
                curr_io_idx = selected_victim;
                curr_io = &IOqueue[curr_io_idx];
                if (curr_io->arr_time <= simulation_time){
                    // printf("%d: %d add %d\n", simulation_time, curr_io->req_no, curr_io->io_disk);
                    curr_io->start_time = ret_simulation_time;
                    if (prev_hand == -1){ // calculate total hand movement
                        tot_movement = tot_movement + curr_io->io_disk;
                    }
                    else{
                        tot_movement = tot_movement + abs(prev_hand - curr_io->io_disk);
                    }
                }
                else{
                    curr_io = nullptr;   
                    curr_io_idx = -1;
                }

            }

        }


        if (curr_io_idx!=-1){
            curr_disk = curr_disk + direction;
             }
        simulation_time++;
        }
    }

int main(int argc, char *argv[]){
    int opt;
    string path; 
    ifstream ifile;
    string line;
    // path = "C:/Users/lab4_assign/input0";
    // shed = new FLOOK();

    while ((opt = getopt(argc, argv, "s:")) != -1) {
        switch (opt) {
            case 's':
            // Resolve algorithm
                if ((optarg[0] == 'n') || (optarg[0] == 'N')) {
                    shed = new FIFO();
                } else if ((optarg[0] == 's') || (optarg[0] == 'S')) {
                    shed = new SSTF();
                } else if ((optarg[0] == 'l') || (optarg[0] == 'L')) {
                    shed = new LOOK();
                } else if ((optarg[0] == 'c') || (optarg[0] == 'C')) {
                    shed = new CLOOK();
                } else if ((optarg[0] == 'f') || (optarg[0] == 'F')) {
                    shed = new FLOOK();
                } else {
                    printf("Invalid IO algorithm!\n");
                    }
                break;
        }
    }

    
    if (optind < argc){ // index of the first non-options array
        path = argv[optind];
    }
    else{
        return 1;
    }

    ifile.open(path);




    // Iterate over number of processes
    string arr_time;
    string io_disk;
    int req_no = 0;
    while (getline(ifile, line)){
        if (line.find("#")!=string::npos){
            continue;}

        else{
            istringstream iss(line);
            iss >> arr_time >> io_disk; 
            int arr_time_int = stoi(arr_time);
            int io_disk_int = stoi(io_disk);
            Request r(req_no, arr_time_int, io_disk_int, -1, -1);
            IOqueue.push_back(r);
            req_no++;
            }  
    }
    simulate();


    // Calculations
    int i;
    sort(completed_IO.begin(), completed_IO.end(), [](const Request& a, const Request& b) {
            return a.req_no < b.req_no;
        });

    for (i=0;i<completed_IO.size();i++){
        Request req = completed_IO[i];
        total_time = max(total_time, req.end_time);
        turnaround = turnaround + req.end_time - req.arr_time;
        io_time = io_time + req.end_time - req.start_time;
        waittime = waittime + req.start_time - req.arr_time;
        max_waittime = max(max_waittime, req.start_time - req.arr_time);
        printf("%5d: %5d %5d %5d\n", req.req_no, req.arr_time, req.start_time, req.end_time);
    }
    io_utilization = double(io_time)/total_time;
    avg_turnaround = double(turnaround)/i;
    avg_waittime = double(waittime)/i;
    printf("SUM: %d %d %.4lf %.2lf %.2lf %d\n", total_time, tot_movement, io_utilization, 
    avg_turnaround, avg_waittime, max_waittime);


    ifile.close();
    return 0;
    }